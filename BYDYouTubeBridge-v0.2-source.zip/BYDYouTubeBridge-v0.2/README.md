# BYD YouTube Bridge v0.2

Experimental Android bridge for the BYD DiLink MediaCenter environment.

## v0.2 features

- Detects the active MediaSession from:
  - `com.android.youtube.premium`
  - `com.android.youtube.music.premium`
  - `com.byd.youtube`
- Mirrors title, artist, duration, position, playback state, artwork, and transport controls.
- Adds an experimental direct BYD ambient-light adapter using reflection on:
  - `android.hardware.bydauto.audio.BYDAutoAudioDevice`
  - `setAmbientLightFreq(...)`
- Includes a one-shot 16-band light test using a frame observed in BYD Music logs.
- Includes microphone-based 16-band spectrum analysis, sending frames roughly every 170–200 ms.

## Important limitation

The direct BYD call may require a system/signature permission. If the status screen reports `SecurityException`, the APK is correctly reaching the BYD API but the firmware is refusing third-party access. Microphone mode reacts to cabin sound, not private YouTube PCM, so other cabin sounds may affect it.

## First test order

1. Install the APK and grant notification and microphone access.
2. Enable notification access for BYD YouTube Bridge.
3. Press **Test BYD lights once**.
4. Read the **Ambient API** status.
5. If the test succeeds, play YouTube and press **Start microphone light sync**.

The app never modifies or replaces the factory MediaCenter APK.
